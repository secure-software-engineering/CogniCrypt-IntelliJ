Binary CrySL rulesets for 
JCA (rulesetversion: 1.0)
BouncyCastle (rulesetversion: 0.4)
Tink (rulesetversion: 0.1)
